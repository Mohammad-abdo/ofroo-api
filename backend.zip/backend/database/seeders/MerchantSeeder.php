<?php

namespace Database\Seeders;

use App\Models\Merchant;
use App\Models\Role;
use App\Models\StoreLocation;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Faker\Factory as Faker;

class MerchantSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $faker = Faker::create('ar_SA');
        $merchantRole = Role::where('name', 'merchant')->first();
        
        // Kuwait cities
        $kuwaitCities = ['الكويت', 'حولي', 'الأحمدي', 'الفروانية', 'مبارك الكبير', 'الجهراء'];

        $merchants = [
            [
                'name' => 'The Avenues Mall',
                'name_ar' => 'مجمع الأفنيوز',
                'name_en' => 'The Avenues Mall',
                'description' => 'Large shopping mall in Kuwait',
                'description_ar' => 'مجمع تجاري كبير في الكويت',
                'description_en' => 'Large shopping mall in Kuwait',
                'address' => 'Al Rai, Kuwait',
                'address_ar' => 'الراي، الكويت',
                'address_en' => 'Al Rai, Kuwait',
                'lat' => 29.3759,
                'lng' => 47.9774,
            ],
            [
                'name' => 'Al Fanar Restaurant',
                'name_ar' => 'مطعم الفنار',
                'name_en' => 'Al Fanar Restaurant',
                'description' => 'Traditional Kuwaiti restaurant',
                'description_ar' => 'مطعم كويتي تقليدي',
                'description_en' => 'Traditional Kuwaiti restaurant',
                'address' => 'Salmiya, Kuwait',
                'address_ar' => 'السالمية، الكويت',
                'address_en' => 'Salmiya, Kuwait',
                'lat' => 29.3375,
                'lng' => 48.0758,
            ],
            [
                'name' => 'Marina Mall',
                'name_ar' => 'مارينا مول',
                'name_en' => 'Marina Mall',
                'description' => 'Shopping mall in Salmiya',
                'description_ar' => 'مجمع تجاري في السالمية',
                'description_en' => 'Shopping mall in Salmiya',
                'address' => 'Salmiya, Kuwait',
                'address_ar' => 'السالمية، الكويت',
                'address_en' => 'Salmiya, Kuwait',
                'lat' => 29.3400,
                'lng' => 48.0800,
            ],
            [
                'name' => 'Kout Mall',
                'name_ar' => 'كويت مول',
                'name_en' => 'Kout Mall',
                'description' => 'Popular shopping destination',
                'description_ar' => 'وجهة تسوق شعبية',
                'description_en' => 'Popular shopping destination',
                'address' => 'Salmiya, Kuwait',
                'address_ar' => 'السالمية، الكويت',
                'address_en' => 'Salmiya, Kuwait',
                'lat' => 29.3300,
                'lng' => 48.0700,
            ],
            [
                'name' => 'Al Tazaj',
                'name_ar' => 'التازج',
                'name_en' => 'Al Tazaj',
                'description' => 'Fast food restaurant chain',
                'description_ar' => 'سلسلة مطاعم الوجبات السريعة',
                'description_en' => 'Fast food restaurant chain',
                'address' => 'Multiple Locations, Kuwait',
                'address_ar' => 'مواقع متعددة، الكويت',
                'address_en' => 'Multiple Locations, Kuwait',
                'lat' => 29.3500,
                'lng' => 48.0900,
            ],
        ];

        foreach ($merchants as $index => $merchantData) {
            $merchantUser = User::create([
                'name' => $merchantData['name'],
                'email' => strtolower(str_replace(' ', '', $merchantData['name'])) . '@merchant.com',
                'phone' => '+965' . (12345681 + $index),
                'password' => Hash::make('password'),
                'language' => 'ar',
                'role_id' => $merchantRole->id,
                'email_verified_at' => now(),
                'city' => $faker->randomElement($kuwaitCities),
                'country' => 'الكويت',
            ]);

            $merchantCity = $faker->randomElement($kuwaitCities);
            $merchant = Merchant::create([
                'user_id' => $merchantUser->id,
                'company_name' => $merchantData['name'],
                'company_name_ar' => $merchantData['name_ar'],
                'company_name_en' => $merchantData['name_en'],
                'description' => $merchantData['description'],
                'description_ar' => $merchantData['description_ar'],
                'description_en' => $merchantData['description_en'],
                'address' => $merchantData['address'],
                'address_ar' => $merchantData['address_ar'],
                'address_en' => $merchantData['address_en'],
                'phone' => '+965' . (12345681 + $index),
                'whatsapp_link' => 'https://wa.me/965' . (12345681 + $index),
                'city' => $merchantCity,
                'country' => 'الكويت',
                'approved' => true,
            ]);

            StoreLocation::create([
                'merchant_id' => $merchant->id,
                'lat' => $merchantData['lat'],
                'lng' => $merchantData['lng'],
                'address' => $merchantData['address'],
                'address_ar' => $merchantData['address_ar'],
                'address_en' => $merchantData['address_en'],
                'google_place_id' => 'ChIJ' . $faker->bothify('????????????????'),
                'opening_hours' => [
                    'monday' => '10:00-22:00',
                    'tuesday' => '10:00-22:00',
                    'wednesday' => '10:00-22:00',
                    'thursday' => '10:00-22:00',
                    'friday' => '14:00-22:00',
                    'saturday' => '10:00-22:00',
                    'sunday' => '10:00-22:00',
                ],
            ]);
        }

        // Create 20 more random merchants
        for ($i = 6; $i <= 25; $i++) {
            $merchantCity = $faker->randomElement($kuwaitCities);
            $merchantUser = User::create([
                'name' => $faker->company(),
                'email' => "merchant{$i}@example.com",
                'phone' => '+965' . $faker->numerify('#######'),
                'password' => Hash::make('password'),
                'language' => 'ar',
                'role_id' => $merchantRole->id,
                'email_verified_at' => $faker->optional(0.9)->dateTimeBetween('-6 months', 'now'),
                'city' => $merchantCity,
                'country' => 'الكويت',
            ]);

            $merchant = Merchant::create([
                'user_id' => $merchantUser->id,
                'company_name' => $faker->company(),
                'company_name_ar' => $faker->company() . ' (عربي)',
                'company_name_en' => $faker->company(),
                'description' => $faker->text(200),
                'description_ar' => $faker->realText(200),
                'description_en' => $faker->text(200),
                'address' => $faker->address(),
                'address_ar' => $faker->address(),
                'address_en' => $faker->address(),
                'phone' => '+965' . $faker->numerify('#######'),
                'whatsapp_link' => 'https://wa.me/965' . $faker->numerify('#######'),
                'city' => $merchantCity,
                'country' => 'الكويت',
                'approved' => $faker->boolean(80),
            ]);

            StoreLocation::create([
                'merchant_id' => $merchant->id,
                'lat' => $faker->latitude(29.0, 29.5),
                'lng' => $faker->longitude(47.5, 48.5),
                'address' => $faker->address(),
                'address_ar' => $faker->address(),
                'address_en' => $faker->address(),
                'google_place_id' => 'ChIJ' . $faker->bothify('????????????????'),
                'opening_hours' => [
                    'monday' => $faker->time('H:i') . '-' . $faker->time('H:i'),
                    'tuesday' => $faker->time('H:i') . '-' . $faker->time('H:i'),
                    'wednesday' => $faker->time('H:i') . '-' . $faker->time('H:i'),
                    'thursday' => $faker->time('H:i') . '-' . $faker->time('H:i'),
                    'friday' => $faker->time('H:i') . '-' . $faker->time('H:i'),
                    'saturday' => $faker->time('H:i') . '-' . $faker->time('H:i'),
                    'sunday' => $faker->time('H:i') . '-' . $faker->time('H:i'),
                ],
            ]);
        }
    }
}
