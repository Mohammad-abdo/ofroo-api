<?php

namespace Database\Seeders;

use App\Models\Merchant;
use App\Models\SupportTicket;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Faker\Factory as Faker;

class SupportSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $faker = Faker::create('ar_SA');
        $users = User::all();
        $merchants = Merchant::all();
        $admins = User::whereHas('role', function ($query) {
            $query->where('name', 'admin');
        })->get();

        $categories = [
            'technical' => ['ar' => 'تقني', 'en' => 'Technical'],
            'financial' => ['ar' => 'مالي', 'en' => 'Financial'],
            'content' => ['ar' => 'محتوى', 'en' => 'Content'],
            'fraud' => ['ar' => 'احتيال', 'en' => 'Fraud'],
            'other' => ['ar' => 'أخرى', 'en' => 'Other'],
        ];

        // Create 100 support tickets
        for ($i = 0; $i < 100; $i++) {
            $user = $users->random();
            $merchant = $faker->optional(0.3) ? $merchants->random() : null;
            $assignedTo = $faker->optional(0.5) ? $admins->random() : null;
            $category = $faker->randomElement(array_keys($categories));

            SupportTicket::create([
                'ticket_number' => 'TKT-' . str_pad($i + 1, 6, '0', STR_PAD_LEFT),
                'user_id' => $user->id,
                'merchant_id' => $merchant ? $merchant->id : null,
                'assigned_to' => $assignedTo ? $assignedTo->id : null,
                'category' => $category,
                'category_ar' => $categories[$category]['ar'],
                'category_en' => $categories[$category]['en'],
                'subject' => $faker->sentence(),
                'description' => $faker->realText(500),
                'priority' => $faker->randomElement(['low', 'medium', 'high', 'urgent']),
                'status' => $faker->randomElement(['open', 'in_progress', 'resolved', 'closed', 'cancelled']),
                'metadata' => [
                    'source' => $faker->randomElement(['web', 'mobile', 'email']),
                ],
                'created_at' => $faker->dateTimeBetween('-3 months', 'now'),
                'resolved_at' => $faker->optional(0.4)->dateTimeBetween('-2 months', 'now'),
            ]);
        }
    }
}
