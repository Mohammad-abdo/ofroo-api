<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('coupons', function (Blueprint $table) {
            // Make order_id nullable since coupons can be created by merchants/admins before orders
            $table->unsignedBigInteger('order_id')->nullable()->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('coupons', function (Blueprint $table) {
            // Before making order_id required, we need to handle NULL values
            // Option 1: Delete coupons with NULL order_id (coupons created by merchants/admins)
            // Option 2: Set a default order_id (not recommended)
            // We'll delete coupons with NULL order_id as they shouldn't exist if order_id is required
            \DB::table('coupons')->whereNull('order_id')->delete();
            
            // Now we can safely make order_id required
            $table->unsignedBigInteger('order_id')->nullable(false)->change();
        });
    }
};
