<?php

use App\Http\Middleware\CheckAdmin;
use App\Http\Middleware\CheckMerchant;
use App\Http\Middleware\CheckPermission;
use App\Http\Middleware\ForceJsonResponse;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            'admin' => CheckAdmin::class,
            'merchant' => CheckMerchant::class,
            'permission' => CheckPermission::class,
        ]);

        // Force JSON responses for all API routes
        $middleware->api(prepend: [
            ForceJsonResponse::class,
        ]);

        // Rate limiting for auth endpoints
        $middleware->throttleApi();
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        // Handle all exceptions for API routes
        $exceptions->render(function (Throwable $e, $request) {
            // Check if this is an API route
            $isApiRoute = $request->is('api/*') || $request->expectsJson();
            
            if ($isApiRoute) {
                // Handle AuthenticationException
                if ($e instanceof \Illuminate\Auth\AuthenticationException) {
                    return response()->json([
                        'message' => 'Unauthenticated',
                        'error' => 'You must be authenticated to access this resource'
                    ], 401);
                }
                
                // Handle ValidationException
                if ($e instanceof \Illuminate\Validation\ValidationException) {
                    return response()->json([
                        'message' => 'Validation failed',
                        'errors' => $e->errors()
                    ], 422);
                }
                
                // Handle ModelNotFoundException
                if ($e instanceof \Illuminate\Database\Eloquent\ModelNotFoundException) {
                    return response()->json([
                        'message' => 'Resource not found',
                        'error' => 'The requested resource could not be found'
                    ], 404);
                }
                
                // Handle NotFoundHttpException
                if ($e instanceof \Symfony\Component\HttpKernel\Exception\NotFoundHttpException) {
                    return response()->json([
                        'message' => 'Route not found',
                        'error' => 'The requested endpoint does not exist'
                    ], 404);
                }
                
                // Handle MethodNotAllowedHttpException
                if ($e instanceof \Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException) {
                    return response()->json([
                        'message' => 'Method not allowed',
                        'error' => 'The HTTP method is not allowed for this endpoint'
                    ], 405);
                }
                
                // Handle all other exceptions (500 errors)
                $statusCode = method_exists($e, 'getStatusCode') ? $e->getStatusCode() : 500;
                
                return response()->json([
                    'message' => $e->getMessage() ?: 'Internal server error',
                    'error' => config('app.debug') ? [
                        'exception' => get_class($e),
                        'file' => $e->getFile(),
                        'line' => $e->getLine(),
                        'trace' => $e->getTraceAsString()
                    ] : 'An error occurred while processing your request'
                ], $statusCode);
            }
        });
    })->create();
