<?php

namespace App\Repositories;

use App\Models\Offer;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Pagination\LengthAwarePaginator;

class OfferRepository extends BaseRepository
{
    public function __construct(Offer $model)
    {
        parent::__construct($model);
    }

    public function getActiveOffers(array $filters = []): LengthAwarePaginator
    {
        $query = $this->model->with(['merchant', 'category', 'location'])
            ->where('status', 'active')
            ->where('start_at', '<=', now())
            ->where('end_at', '>=', now());

        if (isset($filters['category'])) {
            $query->where('category_id', $filters['category']);
        }

        if (isset($filters['merchant'])) {
            $query->where('merchant_id', $filters['merchant']);
        }

        if (isset($filters['search'])) {
            $search = $filters['search'];
            $query->where(function ($q) use ($search) {
                $q->where('title_ar', 'like', "%{$search}%")
                    ->orWhere('title_en', 'like', "%{$search}%")
                    ->orWhere('description_ar', 'like', "%{$search}%")
                    ->orWhere('description_en', 'like', "%{$search}%");
            });
        }

        return $query->orderBy('created_at', 'desc')
            ->paginate($filters['per_page'] ?? 15);
    }

    public function getNearbyOffers(float $lat, float $lng, float $distanceKm = 10): Collection
    {
        return $this->model->with(['merchant', 'category', 'location'])
            ->where('status', 'active')
            ->where('start_at', '<=', now())
            ->where('end_at', '>=', now())
            ->join('store_locations', 'offers.location_id', '=', 'store_locations.id')
            ->select('offers.*')
            ->selectRaw("(
                6371 * acos(
                    cos(radians(?))
                    * cos(radians(store_locations.lat))
                    * cos(radians(store_locations.lng) - radians(?))
                    + sin(radians(?))
                    * sin(radians(store_locations.lat))
                )
            ) AS distance", [$lat, $lng, $lat])
            ->having('distance', '<=', $distanceKm)
            ->orderBy('distance')
            ->get();
    }

    public function getByMerchant(int $merchantId): Collection
    {
        return $this->model->where('merchant_id', $merchantId)
            ->with(['category', 'location'])
            ->orderBy('created_at', 'desc')
            ->get();
    }
}


