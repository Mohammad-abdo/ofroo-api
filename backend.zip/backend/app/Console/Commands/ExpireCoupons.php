<?php

namespace App\Console\Commands;

use App\Models\Coupon;
use App\Models\Offer;
use Illuminate\Console\Command;

class ExpireCoupons extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'coupons:expire';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Expire coupons and offers that have passed their end date';

    /**
     * Execute the console command.
     */
    public function handle(): int
    {
        $this->info('Starting coupon expiration process...');

        // Expire offers
        $expiredOffers = Offer::where('status', 'active')
            ->where('end_at', '<', now())
            ->update(['status' => 'expired']);

        $this->info("Expired {$expiredOffers} offers");

        // Expire coupons for expired offers
        $expiredCoupons = Coupon::whereIn('status', ['reserved', 'activated'])
            ->whereHas('offer', function ($query) {
                $query->where('end_at', '<', now());
            })
            ->update([
                'status' => 'expired',
            ]);

        $this->info("Expired {$expiredCoupons} coupons");

        // Also expire coupons that are older than a certain period (e.g., 90 days) and still reserved
        $oldReservedCoupons = Coupon::where('status', 'reserved')
            ->where('created_at', '<', now()->subDays(90))
            ->update(['status' => 'expired']);

        $this->info("Expired {$oldReservedCoupons} old reserved coupons");

        $this->info('Coupon expiration process completed!');

        return Command::SUCCESS;
    }
}
