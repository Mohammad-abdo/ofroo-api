<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CouponResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'coupon_code' => $this->coupon_code,
            'barcode_value' => $this->barcode_value,
            'status' => $this->status,
            'usage_limit' => $this->usage_limit ?? 1,
            'times_used' => $this->times_used ?? 0,
            'can_be_used' => $this->canBeUsed(),
            'discount_type' => $this->discount_type ?? 'percent',
            'discount_percent' => $this->discount_percent ? (float) $this->discount_percent : null,
            'discount_amount' => $this->discount_amount ? (float) $this->discount_amount : null,
            'reserved_at' => $this->reserved_at?->toIso8601String(),
            'activated_at' => $this->activated_at?->toIso8601String(),
            'used_at' => $this->used_at?->toIso8601String(),
            'expires_at' => $this->expires_at?->toIso8601String(),
            'terms_conditions' => $this->terms_conditions,
            'is_refundable' => $this->is_refundable ?? false,
            'category' => $this->whenLoaded('category', function () {
                return [
                    'id' => $this->category->id,
                    'name_ar' => $this->category->name_ar,
                    'name_en' => $this->category->name_en,
                ];
            }),
            'mall' => $this->whenLoaded('mall', function () {
                return [
                    'id' => $this->mall->id,
                    'name' => $this->mall->name,
                    'name_ar' => $this->mall->name_ar,
                    'name_en' => $this->mall->name_en,
                    'description' => $this->mall->description,
                    'description_ar' => $this->mall->description_ar,
                    'description_en' => $this->mall->description_en,
                    'address' => $this->mall->address,
                    'address_ar' => $this->mall->address_ar,
                    'address_en' => $this->mall->address_en,
                    'city' => $this->mall->city,
                    'country' => $this->mall->country,
                    'phone' => $this->mall->phone,
                    'email' => $this->mall->email,
                    'website' => $this->mall->website,
                    'image_url' => $this->mall->image_url,
                    'images' => $this->mall->images,
                    'opening_hours' => $this->mall->opening_hours,
                    'is_active' => $this->mall->is_active,
                ];
            }),
            'offer' => $this->whenLoaded('offer', function () {
                return [
                    'id' => $this->offer->id,
                    'title_ar' => $this->offer->title_ar,
                    'title_en' => $this->offer->title_en,
                    'price' => (float) $this->offer->price,
                    'merchant' => $this->offer->merchant ? [
                        'id' => $this->offer->merchant->id,
                        'company_name' => $this->offer->merchant->company_name,
                    ] : null,
                ];
            }),
            'order' => $this->whenLoaded('order', function () {
                return [
                    'id' => $this->order->id,
                    'total_amount' => (float) $this->order->total_amount,
                    'payment_status' => $this->order->payment_status,
                ];
            }),
            'created_by_type' => $this->created_by_type,
            'created_at' => $this->created_at->toIso8601String(),
        ];
    }
}
