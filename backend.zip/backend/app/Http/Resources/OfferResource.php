<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class OfferResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $user = $request->user();
        $language = $user?->language ?? 'ar';

        return [
            'id' => $this->id,
            'title' => $language === 'ar' ? $this->title_ar : $this->title_en,
            'title_ar' => $this->title_ar,
            'title_en' => $this->title_en,
            'description' => $language === 'ar' ? $this->description_ar : $this->description_en,
            'description_ar' => $this->description_ar,
            'description_en' => $this->description_en,
            'price' => (float) $this->price,
            'original_price' => $this->original_price ? (float) $this->original_price : null,
            'discount_percent' => $this->discount_percent,
            'images' => $this->images ?? [],
            'total_coupons' => $this->total_coupons,
            'coupons_remaining' => $this->coupons_remaining,
            'start_at' => $this->start_at?->toIso8601String(),
            'end_at' => $this->end_at?->toIso8601String(),
            'status' => $this->status,
            'merchant' => $this->whenLoaded('merchant', function () use ($language) {
                return [
                    'id' => $this->merchant->id,
                    'company_name' => $language === 'ar' ? $this->merchant->company_name_ar : $this->merchant->company_name_en,
                    'company_name_ar' => $this->merchant->company_name_ar,
                    'company_name_en' => $this->merchant->company_name_en,
                ];
            }),
            'category' => $this->whenLoaded('category', function () use ($language) {
                return [
                    'id' => $this->category->id,
                    'name' => $language === 'ar' ? $this->category->name_ar : $this->category->name_en,
                    'name_ar' => $this->category->name_ar,
                    'name_en' => $this->category->name_en,
                ];
            }),
            'location' => $this->whenLoaded('location', function () use ($language) {
                return [
                    'id' => $this->location->id,
                    'lat' => (float) $this->location->lat,
                    'lng' => (float) $this->location->lng,
                    'address' => $language === 'ar' ? $this->location->address_ar : $this->location->address_en,
                    'address_ar' => $this->location->address_ar,
                    'address_en' => $this->location->address_en,
                ];
            }),
            'distance' => $this->when(isset($this->distance), $this->distance),
            'created_at' => $this->created_at->toIso8601String(),
        ];
    }
}
