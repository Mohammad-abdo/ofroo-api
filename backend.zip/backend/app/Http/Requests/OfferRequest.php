<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class OfferRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        $offerId = $this->route('id');

        return [
            'title_ar' => 'required|string|max:255',
            'title_en' => 'nullable|string|max:255',
            'description_ar' => 'nullable|string',
            'description_en' => 'nullable|string',
            'price' => 'required|numeric|min:0',
            'original_price' => 'nullable|numeric|min:0|gt:price',
            'discount_percent' => 'nullable|integer|min:0|max:100',
            'images' => 'nullable|array',
            'images.*' => 'string',
            'total_coupons' => 'required|integer|min:1',
            'start_at' => 'nullable|date',
            'end_at' => 'nullable|date|after:start_at',
            'category_id' => 'required|exists:categories,id',
            'location_id' => 'nullable|exists:store_locations,id',
            'coupon_id' => 'required|exists:coupons,id',
            'status' => 'nullable|in:draft,pending,active,expired',
        ];
    }
}
