<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\OfferResource;
use App\Models\Category;
use App\Models\Offer;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OfferController extends Controller
{
    /**
     * Display a listing of offers with filters
     */
    public function index(Request $request): JsonResponse
    {
        $query = Offer::with(['merchant', 'category', 'location'])
            ->where('status', 'active')
            ->where('start_at', '<=', now())
            ->where('end_at', '>=', now());

        // Filter by category
        if ($request->has('category')) {
            $query->where('category_id', $request->category);
        }

        // Filter by search query
        if ($request->has('q')) {
            $search = $request->q;
            $query->where(function ($q) use ($search) {
                $q->where('title_ar', 'like', "%{$search}%")
                    ->orWhere('title_en', 'like', "%{$search}%")
                    ->orWhere('description_ar', 'like', "%{$search}%")
                    ->orWhere('description_en', 'like', "%{$search}%");
            });
        }

        // Nearby offers (Haversine distance calculation) - Check if GPS is enabled
        if ($request->boolean('nearby') && $request->has('lat') && $request->has('lng')) {
            if (!\App\Services\FeatureFlagService::isGpsEnabled()) {
                return response()->json([
                    'message' => 'GPS feature is disabled',
                ], 403);
            }
            $lat = $request->lat;
            $lng = $request->lng;
            $distance = $request->get('distance', 10000); // Default 10km

            $query->join('store_locations', 'offers.location_id', '=', 'store_locations.id')
                ->select('offers.*')
                ->selectRaw("(
                    6371 * acos(
                        cos(radians(?))
                        * cos(radians(store_locations.lat))
                        * cos(radians(store_locations.lng) - radians(?))
                        + sin(radians(?))
                        * sin(radians(store_locations.lat))
                    )
                ) AS distance", [$lat, $lng, $lat])
                ->having('distance', '<=', $distance / 1000) // Convert meters to km
                ->orderBy('distance');
        } else {
            $query->orderBy('created_at', 'desc');
        }

        $offers = $query->paginate($request->get('per_page', 15));

        return response()->json([
            'data' => OfferResource::collection($offers->items()),
            'meta' => [
                'current_page' => $offers->currentPage(),
                'last_page' => $offers->lastPage(),
                'per_page' => $offers->perPage(),
                'total' => $offers->total(),
            ],
        ]);
    }

    /**
     * Display the specified offer
     */
    public function show(string $id): JsonResponse
    {
        $offer = Offer::with(['merchant', 'category', 'location'])
            ->findOrFail($id);

        return response()->json([
            'data' => new OfferResource($offer),
        ]);
    }

    /**
     * Advanced global search
     */
    public function search(Request $request): JsonResponse
    {
        $searchService = app(\App\Services\SearchService::class);
        $results = $searchService->globalSearch($request->get('q', ''), $request->all());

        return response()->json([
            'data' => $results,
        ]);
    }

    /**
     * Get WhatsApp contact link for offer
     */
    public function whatsappContact(Request $request, string $id): JsonResponse
    {
        $offer = Offer::with('merchant')->findOrFail($id);
        $user = $request->user();

        $whatsappService = app(\App\Services\WhatsappService::class);

        if (!$whatsappService->isEnabled($offer->merchant)) {
            return response()->json([
                'message' => 'WhatsApp contact is not available for this merchant',
            ], 400);
        }

        $link = $whatsappService->generateContactLink($offer->merchant, $offer, $user);

        return response()->json([
            'data' => [
                'whatsapp_link' => $link,
                'merchant_name' => $offer->merchant->company_name,
                'offer_title' => $offer->title_ar ?? $offer->title_en,
            ],
        ]);
    }
}
