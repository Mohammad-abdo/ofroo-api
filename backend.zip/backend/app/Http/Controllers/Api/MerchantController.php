<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\OfferRequest;
use App\Http\Resources\OfferResource;
use App\Models\Coupon;
use App\Models\Merchant;
use App\Models\Offer;
use App\Models\Order;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MerchantController extends Controller
{
    /**
     * Get merchant offers
     */
    public function offers(Request $request): JsonResponse
    {
        $user = $request->user();
        $merchant = Merchant::where('user_id', $user->id)->firstOrFail();

        $offers = Offer::with(['category', 'location'])
            ->where('merchant_id', $merchant->id)
            ->orderBy('created_at', 'desc')
            ->paginate($request->get('per_page', 15));

        return response()->json([
            'data' => OfferResource::collection($offers->items()),
            'meta' => [
                'current_page' => $offers->currentPage(),
                'last_page' => $offers->lastPage(),
                'per_page' => $offers->perPage(),
                'total' => $offers->total(),
            ],
        ]);
    }

    /**
     * Create offer - requires coupon_id
     */
    public function createOffer(OfferRequest $request): JsonResponse
    {
        $user = $request->user();
        $merchant = Merchant::where('user_id', $user->id)->firstOrFail();

        // Validate coupon exists and belongs to the same category
        if ($request->has('coupon_id')) {
            $coupon = Coupon::findOrFail($request->coupon_id);
            
            // Check if coupon belongs to the same category as offer
            if ($coupon->category_id != $request->category_id) {
                return response()->json([
                    'message' => 'Coupon must belong to the same category as the offer',
                ], 422);
            }
            
            // Check if coupon is already assigned to another offer
            if ($coupon->offer_id) {
                return response()->json([
                    'message' => 'This coupon is already assigned to another offer',
                ], 422);
            }
        } else {
            return response()->json([
                'message' => 'Coupon is required when creating an offer',
            ], 422);
        }

        $offer = Offer::create([
            'merchant_id' => $merchant->id,
            'category_id' => $request->category_id,
            'location_id' => $request->location_id,
            'coupon_id' => $request->coupon_id,
            'title_ar' => $request->title_ar,
            'title_en' => $request->title_en,
            'description_ar' => $request->description_ar,
            'description_en' => $request->description_en,
            'price' => $request->price,
            'original_price' => $request->original_price,
            'discount_percent' => $request->discount_percent ?? 0,
            'images' => $request->images ?? [],
            'total_coupons' => $request->total_coupons,
            'coupons_remaining' => $request->total_coupons,
            'start_at' => $request->start_at,
            'end_at' => $request->end_at,
            'status' => $request->status ?? 'pending', // Requires admin approval
        ]);

        // Update coupon to link it to the offer
        $coupon->update(['offer_id' => $offer->id]);

        return response()->json([
            'message' => 'Offer created successfully. Waiting for admin approval.',
            'data' => new OfferResource($offer->load(['category', 'location', 'coupon'])),
        ], 201);
    }

    /**
     * Update offer
     */
    public function updateOffer(OfferRequest $request, string $id): JsonResponse
    {
        $user = $request->user();
        $merchant = Merchant::where('user_id', $user->id)->firstOrFail();

        $offer = Offer::where('merchant_id', $merchant->id)
            ->findOrFail($id);

        $offer->update([
            'category_id' => $request->category_id ?? $offer->category_id,
            'location_id' => $request->location_id ?? $offer->location_id,
            'title_ar' => $request->title_ar ?? $offer->title_ar,
            'title_en' => $request->title_en ?? $offer->title_en,
            'description_ar' => $request->description_ar ?? $offer->description_ar,
            'description_en' => $request->description_en ?? $offer->description_en,
            'price' => $request->price ?? $offer->price,
            'original_price' => $request->original_price ?? $offer->original_price,
            'discount_percent' => $request->discount_percent ?? $offer->discount_percent,
            'images' => $request->images ?? $offer->images,
            'total_coupons' => $request->total_coupons ?? $offer->total_coupons,
            'start_at' => $request->start_at ?? $offer->start_at,
            'end_at' => $request->end_at ?? $offer->end_at,
            'status' => $request->status ?? $offer->status,
        ]);

        return response()->json([
            'message' => 'Offer updated successfully',
            'data' => new OfferResource($offer->load(['category', 'location'])),
        ]);
    }

    /**
     * Delete offer
     */
    public function deleteOffer(Request $request, string $id): JsonResponse
    {
        $user = $request->user();
        $merchant = Merchant::where('user_id', $user->id)->firstOrFail();

        $offer = Offer::where('merchant_id', $merchant->id)
            ->findOrFail($id);

        // Only allow deletion if no coupons have been generated
        if ($offer->coupons()->where('status', '!=', 'cancelled')->exists()) {
            return response()->json([
                'message' => 'Cannot delete offer with active coupons',
            ], 400);
        }

        $offer->delete();

        return response()->json([
            'message' => 'Offer deleted successfully',
        ]);
    }

    /**
     * Get merchant orders
     */
    public function orders(Request $request): JsonResponse
    {
        $user = $request->user();
        $merchant = Merchant::where('user_id', $user->id)->firstOrFail();

        $orders = Order::with(['user', 'items.offer', 'coupons'])
            ->where('merchant_id', $merchant->id)
            ->where('payment_status', 'paid') // Only paid orders
            ->orderBy('created_at', 'desc')
            ->paginate($request->get('per_page', 15));

        return response()->json([
            'data' => $orders->items(),
            'meta' => [
                'current_page' => $orders->currentPage(),
                'last_page' => $orders->lastPage(),
                'per_page' => $orders->perPage(),
                'total' => $orders->total(),
            ],
        ]);
    }

    /**
     * Activate coupon (scan barcode flow)
     */
    public function activateCoupon(Request $request, string $id): JsonResponse
    {
        $user = $request->user();
        $merchant = Merchant::where('user_id', $user->id)->firstOrFail();

        $coupon = Coupon::with(['offer', 'order'])
            ->whereHas('offer', function ($query) use ($merchant) {
                $query->where('merchant_id', $merchant->id);
            })
            ->findOrFail($id);

        // Validate order payment status
        if ($coupon->order->payment_status !== 'paid') {
            return response()->json([
                'message' => 'Order payment not confirmed',
            ], 400);
        }

        if ($coupon->status !== 'reserved') {
            return response()->json([
                'message' => 'Coupon cannot be activated. Current status: ' . $coupon->status,
            ], 400);
        }

        $coupon->update([
            'status' => 'activated',
            'activated_at' => now(),
        ]);

        // TODO: Send notification to user
        // dispatch(new SendCouponActivatedNotificationJob($coupon));

        return response()->json([
            'message' => 'Coupon activated successfully',
            'data' => [
                'coupon' => [
                    'id' => $coupon->id,
                    'coupon_code' => $coupon->coupon_code,
                    'status' => $coupon->status,
                    'activated_at' => $coupon->activated_at->toIso8601String(),
                ],
            ],
        ]);
    }

    /**
     * Get merchant store locations
     */
    public function storeLocations(Request $request): JsonResponse
    {
        $user = $request->user();
        $merchant = Merchant::where('user_id', $user->id)->firstOrFail();

        $locations = $merchant->storeLocations()
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json([
            'data' => $locations->map(function ($location) {
                return [
                    'id' => $location->id,
                    'lat' => (float) $location->lat,
                    'lng' => (float) $location->lng,
                    'address' => $location->address,
                    'address_ar' => $location->address_ar,
                    'address_en' => $location->address_en,
                    'google_place_id' => $location->google_place_id,
                    'opening_hours' => $location->opening_hours,
                ];
            }),
        ]);
    }

    /**
     * Create store location
     */
    public function createStoreLocation(Request $request): JsonResponse
    {
        $request->validate([
            'lat' => 'required|numeric|between:-90,90',
            'lng' => 'required|numeric|between:-180,180',
            'address' => 'nullable|string|max:500',
            'address_ar' => 'nullable|string|max:500',
            'address_en' => 'nullable|string|max:500',
            'google_place_id' => 'nullable|string|max:255',
            'opening_hours' => 'nullable|array',
        ]);

        $user = $request->user();
        $merchant = Merchant::where('user_id', $user->id)->firstOrFail();

        $location = $merchant->storeLocations()->create([
            'lat' => $request->lat,
            'lng' => $request->lng,
            'address' => $request->address,
            'address_ar' => $request->address_ar,
            'address_en' => $request->address_en,
            'google_place_id' => $request->google_place_id,
            'opening_hours' => $request->opening_hours,
        ]);

        return response()->json([
            'message' => 'Store location created successfully',
            'data' => $location,
        ], 201);
    }

    /**
     * Create coupon (Merchant)
     * Merchants can create coupons for their category
     */
    public function createCoupon(Request $request): JsonResponse
    {
        $user = $request->user();
        $merchant = Merchant::where('user_id', $user->id)->firstOrFail();

        $validator = \Illuminate\Support\Facades\Validator::make($request->all(), [
            'category_id' => 'required|exists:categories,id',
            'coupon_code' => 'nullable|string|unique:coupons,coupon_code',
            'usage_limit' => 'required|integer|min:1',
            'discount_percent' => 'nullable|numeric|min:0|max:100',
            'discount_amount' => 'nullable|numeric|min:0',
            'status' => 'nullable|in:pending,active,inactive',
            'expires_at' => 'nullable|date|after:today',
            'terms_conditions' => 'nullable|string',
            'is_refundable' => 'nullable|boolean',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'message' => 'Validation error',
                'errors' => $validator->errors(),
            ], 422);
        }

        // Generate coupon code if not provided
        $couponCode = $request->coupon_code ?? 'CPN-' . strtoupper(uniqid());

        $coupon = Coupon::create([
            'category_id' => $request->category_id,
            'coupon_code' => $couponCode,
            'barcode_value' => $request->barcode_value ?? $couponCode,
            'usage_limit' => $request->usage_limit,
            'times_used' => 0,
            'status' => $request->status ?? 'active',
            'expires_at' => $request->expires_at,
            'terms_conditions' => $request->terms_conditions,
            'is_refundable' => $request->boolean('is_refundable', false),
            'created_by' => $merchant->id,
            'created_by_type' => 'merchant',
        ]);

        return response()->json([
            'message' => 'Coupon created successfully',
            'data' => new \App\Http\Resources\CouponResource($coupon->load(['category'])),
        ], 201);
    }

    /**
     * Get merchant coupons
     */
    public function getCoupons(Request $request): JsonResponse
    {
        $user = $request->user();
        $merchant = Merchant::where('user_id', $user->id)->firstOrFail();

        $query = Coupon::with(['category', 'offer'])
            ->where('created_by', $merchant->id)
            ->where('created_by_type', 'merchant');

        if ($request->has('category_id')) {
            $query->where('category_id', $request->category_id);
        }

        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        $coupons = $query->orderBy('created_at', 'desc')
            ->paginate($request->get('per_page', 15));

        return response()->json([
            'data' => \App\Http\Resources\CouponResource::collection($coupons->getCollection()),
            'meta' => [
                'current_page' => $coupons->currentPage(),
                'last_page' => $coupons->lastPage(),
                'per_page' => $coupons->perPage(),
                'total' => $coupons->total(),
            ],
        ]);
    }

    /**
     * Get merchant statistics
     */
    public function statistics(Request $request): JsonResponse
    {
        $user = $request->user();
        $merchant = Merchant::where('user_id', $user->id)->firstOrFail();

        $stats = [
            'total_offers' => $merchant->offers()->count(),
            'active_offers' => $merchant->offers()->where('status', 'active')->count(),
            'pending_offers' => $merchant->offers()->where('status', 'pending')->count(),
            'total_orders' => $merchant->orders()->where('payment_status', 'paid')->count(),
            'total_revenue' => $merchant->orders()->where('payment_status', 'paid')->sum('total_amount'),
            'total_coupons_activated' => $merchant->orders()
                ->where('payment_status', 'paid')
                ->withCount(['coupons' => function ($query) {
                    $query->where('status', 'activated');
                }])
                ->get()
                ->sum('coupons_count'),
            'total_coupons_created' => Coupon::where('created_by', $merchant->id)
                ->where('created_by_type', 'merchant')
                ->count(),
        ];

        return response()->json([
            'data' => $stats,
        ]);
    }
}