<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Coupon;
use App\Models\Merchant;
use App\Services\QrActivationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class QrActivationController extends Controller
{
    protected QrActivationService $qrService;

    public function __construct(QrActivationService $qrService)
    {
        $this->qrService = $qrService;
    }

    /**
     * Scan and activate QR code
     */
    public function scanAndActivate(Request $request): JsonResponse
    {
        $request->validate([
            'coupon_code' => 'required|string',
            'device_id' => 'nullable|string',
            'latitude' => 'nullable|numeric',
            'longitude' => 'nullable|numeric',
        ]);

        $user = $request->user();
        $merchant = Merchant::where('user_id', $user->id)->firstOrFail();

        $result = $this->qrService->activateCoupon(
            $request->coupon_code,
            $merchant,
            $user,
            [
                'device_id' => $request->device_id,
                'ip_address' => $request->ip(),
                'latitude' => $request->latitude,
                'longitude' => $request->longitude,
                'location' => $request->location,
            ]
        );

        if (!$result['success']) {
            return response()->json([
                'message' => $result['message'],
                'data' => $result['coupon'] ?? null,
            ], 400);
        }

        return response()->json([
            'message' => $result['message'],
            'data' => $result['coupon'],
        ]);
    }

    /**
     * Validate QR code without activating
     */
    public function validateQr(Request $request): JsonResponse
    {
        $request->validate([
            'coupon_code' => 'required|string',
        ]);

        $user = $request->user();
        $merchant = Merchant::where('user_id', $user->id)->firstOrFail();

        $result = $this->qrService->validateQrCode($request->coupon_code, $merchant);

        return response()->json($result);
    }

    /**
     * Get QR scanner page data
     */
    public function scannerPage(Request $request): JsonResponse
    {
        $user = $request->user();
        $merchant = Merchant::where('user_id', $user->id)->firstOrFail();

        // Get pending/reserved coupons for this merchant
        $pendingCoupons = Coupon::whereHas('offer', function ($q) use ($merchant) {
            $q->where('merchant_id', $merchant->id);
        })
        ->whereIn('status', ['reserved', 'paid'])
        ->with(['user', 'offer'])
        ->orderBy('created_at', 'desc')
        ->limit(20)
        ->get();

        return response()->json([
            'data' => [
                'pending_count' => $pendingCoupons->count(),
                'recent_coupons' => $pendingCoupons,
            ],
        ]);
    }
}
