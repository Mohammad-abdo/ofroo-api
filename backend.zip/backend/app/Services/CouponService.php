<?php

namespace App\Services;

use App\Models\Coupon;
use App\Models\Offer;
use App\Models\Order;
use Illuminate\Support\Str;
use Milon\Barcode\Facades\DNS1DFacade;
use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;

class CouponService
{
    /**
     * Generate unique coupon code
     */
    public function generateCouponCode(): string
    {
        do {
            $code = 'OFR-' . strtoupper(Str::random(8));
        } while (Coupon::where('coupon_code', $code)->exists());

        return $code;
    }

    /**
     * Generate barcode value
     */
    public function generateBarcodeValue(Coupon $coupon): string
    {
        return (string) $coupon->id . str_pad($coupon->order_id, 8, '0', STR_PAD_LEFT);
    }

    /**
     * Generate barcode image
     */
    public function generateBarcodeImage(string $barcodeValue): string
    {
        try {
            $barcode = DNS1DFacade::getBarcodePNG($barcodeValue, 'C128', 2, 50);
            return base64_encode($barcode);
        } catch (\Exception $e) {
            \Log::error('Barcode generation failed: ' . $e->getMessage());
            return '';
        }
    }

    /**
     * Generate QR code image
     */
    public function generateQRCodeImage(string $data): string
    {
        try {
            $qrCode = QrCode::create($data)
                ->setSize(300)
                ->setMargin(10);

            $writer = new PngWriter();
            $result = $writer->write($qrCode);

            return base64_encode($result->getString());
        } catch (\Exception $e) {
            \Log::error('QR code generation failed: ' . $e->getMessage());
            return '';
        }
    }

    /**
     * Create coupons for an order
     */
    public function createCouponsForOrder(Order $order): array
    {
        $coupons = [];
        $paymentMethod = $order->payment_method ?? 'cash';

        foreach ($order->items as $item) {
            for ($i = 0; $i < $item->quantity; $i++) {
                // Determine initial status based on payment method
                $initialStatus = 'pending';
                if ($paymentMethod === 'cash') {
                    $initialStatus = 'pending'; // Will change to 'reserved' after cash payment confirmation
                } elseif ($order->payment_status === 'paid') {
                    $initialStatus = 'paid'; // Online payment completed
                }

                $coupon = Coupon::create([
                    'order_id' => $order->id,
                    'offer_id' => $item->offer_id,
                    'coupon_code' => $this->generateCouponCode(),
                    'user_id' => $order->user_id,
                    'status' => $initialStatus,
                    'payment_method' => $paymentMethod,
                    'reserved_at' => $initialStatus !== 'pending' ? now() : null,
                    'is_refundable' => true,
                ]);

                // Generate barcode and QR code
                $barcodeValue = $this->generateBarcodeValue($coupon);
                $qrCodeData = $coupon->coupon_code; // QR contains coupon code
                
                // Generate QR code image and save
                $qrCodeImage = $this->generateQRCodeImage($qrCodeData);
                if ($qrCodeImage) {
                    $qrPath = 'coupons/qr/' . $coupon->coupon_code . '.png';
                    \Illuminate\Support\Facades\Storage::disk('public')->put($qrPath, base64_decode($qrCodeImage));
                    $coupon->update([
                        'barcode_value' => $barcodeValue,
                        'qr_code_path' => $qrPath,
                    ]);
                } else {
                    $coupon->update(['barcode_value' => $barcodeValue]);
                }

                $coupons[] = $coupon;
            }
        }

        return $coupons;
    }

    /**
     * Update coupon status after payment
     */
    public function updateCouponStatusAfterPayment(Order $order): void
    {
        $coupons = Coupon::where('order_id', $order->id)->get();

        foreach ($coupons as $coupon) {
            if ($order->payment_status === 'paid') {
                // For cash: change from 'pending' to 'reserved'
                // For online: change from 'pending' to 'paid'
                $newStatus = $order->payment_method === 'cash' ? 'reserved' : 'paid';
                
                $coupon->update([
                    'status' => $newStatus,
                    'reserved_at' => now(),
                ]);
            }
        }
    }

    /**
     * Activate coupon
     */
    public function activateCoupon(Coupon $coupon): bool
    {
        if ($coupon->status !== 'reserved') {
            return false;
        }

        $order = $coupon->order;
        if ($order->payment_status !== 'paid') {
            return false;
        }

        $coupon->update([
            'status' => 'activated',
            'activated_at' => now(),
        ]);

        return true;
    }
}

