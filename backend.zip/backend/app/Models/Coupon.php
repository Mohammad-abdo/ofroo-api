<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Coupon extends Model
{
    protected $fillable = [
        'order_id',
        'offer_id',
        'category_id',
        'mall_id',
        'coupon_code',
        'barcode_value',
        'qr_code_path',
        'user_id',
        'status',
        'payment_method',
        'reserved_at',
        'activated_at',
        'activated_by',
        'activation_device_id',
        'activation_ip',
        'used_at',
        'expires_at',
        'terms_conditions',
        'is_refundable',
        'usage_limit',
        'times_used',
        'discount_percent',
        'discount_amount',
        'discount_type',
        'created_by',
        'created_by_type',
    ];

    protected function casts(): array
    {
        return [
            'reserved_at' => 'datetime',
            'activated_at' => 'datetime',
            'used_at' => 'datetime',
            'expires_at' => 'datetime',
            'is_refundable' => 'boolean',
            'discount_percent' => 'decimal:2',
            'discount_amount' => 'decimal:2',
        ];
    }

    /**
     * Get the order that owns the coupon.
     */
    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    /**
     * Get the offer that owns the coupon.
     */
    public function offer(): BelongsTo
    {
        return $this->belongsTo(Offer::class);
    }

    /**
     * Get the category that owns the coupon.
     */
    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    /**
     * Get the mall that the coupon belongs to.
     */
    public function mall(): BelongsTo
    {
        return $this->belongsTo(Mall::class);
    }

    /**
     * Get the user that owns the coupon.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
    
    /**
     * Get the merchant who created the coupon.
     */
    public function createdByMerchant(): BelongsTo
    {
        return $this->belongsTo(Merchant::class, 'created_by');
    }
    
    /**
     * Check if coupon can be used (not exceeded usage limit)
     */
    public function canBeUsed(): bool
    {
        return $this->times_used < $this->usage_limit;
    }
    
    /**
     * Increment usage count
     */
    public function incrementUsage(): void
    {
        $this->increment('times_used');
    }

    /**
     * Get user who activated the coupon
     */
    public function activatedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'activated_by');
    }

    /**
     * Get activation report
     */
    public function activationReport()
    {
        return $this->hasOne(\App\Models\ActivationReport::class);
    }
}
